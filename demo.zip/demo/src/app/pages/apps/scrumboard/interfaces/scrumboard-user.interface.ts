export interface ScrumboardUser {
  name: string;
  imageSrc: string;
}
