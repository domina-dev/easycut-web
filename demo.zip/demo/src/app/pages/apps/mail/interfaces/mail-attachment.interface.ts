export interface MailAttachment {
  label: string;
  type: string;
  imgUrl?: string;
}
